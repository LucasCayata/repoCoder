def funcion_modulo2():
    print("Hola, soy funcion del modulo2")