def funcion_modulo1():
    print("Hola, soy una funcion del modulo1")